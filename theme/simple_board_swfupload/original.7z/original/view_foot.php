<?php if(!defined('__GRBOARD__')) exit(); ?>
<div class="viewFooter">
<ul class="viewMenu">
	<li><span class="button large"><a href="<?php echo $grboard; ?>/write.php?id=<?php echo $id; ?>&amp;mode=modify&amp;articleNo=<?php echo $articleNo; ?>&amp;page=<?php echo $page; ?>&amp;clickCategory=<?php echo $clickCategory; ?>" title="글을 수정합니다">수정하기</a></span></li>
	<li><span class="button large"><a href="<?php echo $grboard; ?>/delete.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;targetTable=bbs&amp;readyWork=delete" onclick="deleteArticleOk('<?php echo $id.'\', '.$articleNo; ?>); return false;" title="이 게시물을 삭제합니다." class="red">삭제하기</a></span></li>
</ul>

<nav class="viewMenu">
	<ul>
		<li><span class="button large"><a href="<?php echo $grboard; ?>/write.php?id=<?php echo $id; ?>&amp;clickCategory=<?php echo $clickCategory; ?>" title="글을 작성합니다">글쓰기</a></span></li>
		<li><span class="button large"><a href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;page=<?php echo $page; ?>&amp;searchOption=<?php echo $searchOption; ?>&amp;searchText=<?php echo urlencode($searchText); ?>&amp;clickCategory=<?php echo $clickCategory; ?>" title="목록을 봅니다">목록</a></span></li>
	</ul>
</nav>
</div>

<?php if(!$isOutlogin): /* 아웃로그인 사용하지 않을 때에만 출력 */?>
<nav class="listTopMenu">
	<ul>
		<?php if($isAdmin): /* 관리자만 쓸 수 있는 기능버튼 */ ?><li><a href="<?php echo $grboard; ?>/admin_board.php?boardID=<?php echo $id; ?>" onclick="window.open(this.href, '_blank'); return false;" title="관리자 화면으로 가서 이 게시판 설정을 변경 합니다. (새창으로 열립니다.)">관리자</a></li><?php endif;?>
	<?php if($isMember): /* 여기서부터는 로그인 후 출력 */ ?>
		<li><a href="<?php echo $grboard; ?>/info.php?boardId=<?php echo $id; ?>" title="내 정보를 봅니다.">내정보</a></li>
		<li><a href="<?php echo $grboard; ?>/logout.php?id=<?php echo $id; ?>" title="로그아웃 합니다.">로그아웃</a></li>
		<li><a href="<?php echo $grboard; ?>/view_memo.php" id="viewMemoBtn" title="내 쪽지함을 열어 봅니다.">쪽지함</a></li>
		<li><a href="<?php echo $grboard; ?>/view_scrap.php" id="viewScrapBtn" title="내 스크랩북을 열어 봅니다.">스크랩</a></li>
	<?php endif; ?>

	<?php if(!$isMember): /* 여기서부터는 로그인 안한 상태일 때 출력 */ ?>
		<li><a href="<?php echo $grboard; ?>/login.php?boardID=<?php echo $id; ?>" title="로그인 합니다.">로그인</a></li>
		<li><a href="<?php echo $grboard; ?>/join.php?joinInBoard=1&amp;boardId=<?php echo $id; ?>" title="멤버로 등록 합니다.">가입</a></li>
	<?php endif; ?>
	</ul>
</nav>
<?php endif; ?>

<?php if(!$isViewList): ?>
	</section>
	<form id="list" action="/" method="post"><input type="hidden" id="id" value="<?php echo $id; ?>" /></form>
	<div id="viewMemberInfo" style="display: none" onmouseout="showOff();"></div>
<?php endif; ?>

<script type="text/javascript">
var GRBOARD = '<?php echo $grboard; ?>/';
var USE_CO_EDITOR = <?php if($tmpFetchBoard['is_comment_editor']) { ?>true<?php } else { ?>false<?php } ?>;
</script>
<script type="text/javascript" src="<?php echo $grboard; ?>/js/highslide-full.packed.js"></script>
<script type="text/javascript" src="<?php echo $grboard; ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $grboard; ?>/js/swfobject.js"></script>
<script type="text/javascript" src="<?php echo $grboard.'/'.$theme; ?>/view.js"></script>
<script type="text/javascript" src="<?php echo $grboard; ?>/js/member_info.js"></script>