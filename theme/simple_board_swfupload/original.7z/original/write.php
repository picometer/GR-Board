<?php
if(!defined('__GRBOARD__')) exit();

if($mode) $writeTitle = '기존의 글을 수정합니다';
else $writeTitle = '새로운 게시물을 작성합니다';

include $theme . '/head.php';
?>

<!-- 글작성 폼 시작 (이 부분은 수정하지 마세요) -->
<form id="write" method="post" action="<?php echo $grboard; ?>/write_ok.php" onsubmit="return checkWriteValue(<?php echo $isMember; ?>);" enctype="multipart/form-data">
<section class="write">
<div>
	<input type="hidden" name="mode" value="<?php echo $mode; ?>" />
	<input type="hidden" name="page" value="<?php echo $page; ?>" />
	<input type="hidden" name="id" value="<?php echo $id; ?>" />
	<input type="hidden" name="articleNo" value="<?php echo $articleNo; ?>" />
	<input type="hidden" name="autosaveTime" value="<?php echo time(); ?>" />
	<input type="hidden" name="isReported" value="<?php echo $isReported; ?>" />
	<input type="hidden" name="clickCategory" value="<?php echo $clickCategory; ?>" />
</div>

<h1><?php echo $writeTitle; ?></h1>
<div class="header">
<?php if($isAdmin || $isMaster): ?>
	<div class="ck_notice">
		<label title="이 게시판 최상위에 매달아 놓습니다." for="is_notice">공지</label>
		<input type="checkbox" id="is_notice" name="is_notice" value="1" <?php echo (($modify['is_notice'])?'checked="checked"':''); ?> />
	</div>
<?php endif; ?>
	<div class="ck_screet">
		<label for="is_secret" title="체크하면 비밀글로 등록되어 작성자와 이 게시판 마스터, 관리자만이 볼 수 있습니다.">비밀글</label>
		<input type="checkbox" id="is_secret" name="is_secret" value="1" <?php echo (($modify['is_secret'])?'checked="checked"':''); ?> /> 
	</div>
	<div class="ck_subject">
		<label class="blind" for="subject">제목</label>
		<input type="text" id="subject" name="subject" size="73" class="input" value="<?php echo $subject?>" />
	</div>
<?php if($isCategory): ?>
	<div class="ck_category">
		<label class="blind">카테고리</label>
		 <?php echo $category; ?>
	</div>
<?php endif; ?>
</div>

<div id="editableBox">
	<textarea name="content" class="textarea" rows="15"><?php echo $content; ?></textarea>
	<?php $allowTag = $GR->getArray('select is_html from '.$dbFIX.'board_list where id = \''.$id.'\''); ?>
	<ul class="helper">
		<li><span>사용가능한 TAG: </span><?php echo $allowTag[is_html]; ?></li>
		<?php if($tmpFetchBoard['is_editor']): ?><li id="writePreviewBox">[임시저장] 버튼을 자주 눌러주세요. 불의의 사고로 작성중인 글이 삭제되는 것을 방지합니다.</li><?php endif; ?>
	</ul>
</div>

<ul class="addInfo">
	<li>
		<label for="tag">태그</label>
		<input type="text" name="tag" id="tag" class="input" onkeydown="tagAssist(this.value, '<?php echo $id; ?>');" style="width: 350px" value="<?php echo $modify['tag']; ?>" title="태그(tag/꼬리표)를 통해 글의 핵심단어를 보여줄 수 있습니다." /> <span class="info">( <strong>,</strong> 콤마로 단어 구분)</span>
		<div id="searchTags" style="display: none"></div>
	</li>
	<li>
		<label for="link1">링크 1</label>
		<input type="text" name="link1" id="link1" size="73" class="input" value="<?php echo $modify['link1']; ?>" />
	</li>
	<li>
		<label for="link2">링크 2</label>
		<input type="text" name="link2" id="link2" size="73" class="input" value="<?php echo $modify['link2']; ?>" />
	</li>
<?php if(!$mode): ?>
	<li>
		<label for="trackback" title="다른 게시판/블로그에 관련된 글을 원거리에서 달 수 있습니다.">트랙백</label>
		<input type="text" id="trackback" name="trackback" size="73" class="input" value="<?php echo $modify['trackback']; ?>" />
	</li>
<?php endif; ?>
</ul>

<div id="fileUploadField">
<?php if($totalFiles>2) { if($isAdmin || $isMaster) { ?>
	<p class="waring">4개이상의 기본첨부파일 필드를 멀티업로더와 함께 사용하고 계십니다. <br />필드수가 늘어날 수록 글작성시 스크롤이 늘어나 불편을 줄 수 있으므로 기본첨부파일을 제거하시거나 1~2개만 사용하시는 것을 권장합니다.<br /><strong>(이 메세지는 게시판관리자와 총 관리자에게만 보입니다.)</strong></p>
<?php } } ?>
<?php if(isset($totalFiles)): /* 일반 첨부파일 */ ?>
	<ol class="nomalFileUp">
	<?php for($tmp=1; $tmp<=$totalFiles; $tmp++): ?>
		<li>
			<label for="file<?php echo $tmp; ?>">첨부파일 <?php echo $tmp; ?></label>
			<input type="file" name="file<?php echo $tmp; ?>" id="file<?php echo $tmp; ?>" class="input" />
		</li>
	<?php if($oldFile[$tmp-1]): ?>
		<li class="uploade">
			<p><strong><?php echo end(explode('/', $oldFile[$tmp-1])); ?></strong>이 첨부되어 있습니다.</p>
			<input type="checkbox" name="delete<?php echo $tmp; ?>" id="delete<?php echo $tmp; ?>" value="<?php echo $oldFile[$tmp-1]; ?>"> <label for="delete<?php echo $tmp; ?>">파일삭제</label>
		</li>
	<?php endif; endfor;  ?>
	<?php
				if($mode == 'modify'): /* 추가 첨부파일이 올려져 있을 때 (글수정시) @컴센스, @이동규 */
					$getExtendPds = $GR->query("select no, file_route from ".$dbFIX."pds_extend where id = '".$id."' and article_num = ".$articleNo);
					while($extPds = $GR->fetch($getExtendPds)):
						$getPdsList = $GR->getArray('select no, name from '.$dbFIX.'pds_list where type = 1 and uid = '.$extPds['no']);
						if($getPdsList['no']) $filename = end(explode('/', $getPdsList['name']));
	?>
		<li class="uploade">
			<p><strong><?php echo end(explode('/', $oldFile[$tmp-1])); ?> <?php echo $filename;  ?></strong>이 멀티업로드 되어있습니다.<p>
			<input type="checkbox" id="dlelte_add<?php echo $extPds['no']; ?>" name="deleteExtendPds[]" value="<?php echo $extPds['no']; ?>"> <label for="dlelte_add<?php echo $extPds['no']; ?>">파일삭제</label>
		</li>
	<?php endwhile; endif; ?>
	</ol>
	<?php if($tmpFetchBoard['is_editor']){ ?>
	<div id="upload_more_round">
  	    <div id="upload_more_tool">
  	      <ul>
  	        <li><span id="swfUpBtnforGRBOARD"></span></li>
  	        <li><img id="btnCancel" src="<?php echo $grboard.'/'.$theme; ?>/image/flashupload_cancel.gif" alt="멀티업로드 취소" onclick="swfu.cancelQueue();" title="클릭하시면 멀티업로드로 업로드중이던 파일 전송을 취소합니다." /></li>
  	        <li><div id="divStatus">파일을 추가해주세요.</div></li>
  	      </ul>
  	    </div>
  	    <div id="upload_more_content">
  	      <div id="flashHistory" style="display: none"><div id="fsUploadProgress"></div></div>
  	    </div>
  	  </div>
	  <?php } else { if($isAdmin || $isMaster) { ?>
	  <p class="waring">멀티업로더는 위지윅애디터(TinyMCE) 사용에 체크하셔야 이용 가능합니다.<br /><strong>(이 메세지는 게시판관리자와 총 관리자에게만 보입니다.</strong></p>
	  <?php }} ?>
</div>
<?php endif; ?>
				
<div class="setting">
	<ul class="list1">
		<li><strong class="name" style="vertical-align: top;">추가기능</strong>
			<ul class="list2">
				<li>
					<input type="checkbox" name="is_alert" id="is_alert" value="1" <?php echo (($modify['bad'] && $modify['bad']<-10)?'checked="checked"':''); ?> onclick="useAlert();" /> 
					<label for="is_alert" title="글 보기시 경고문구를 클릭해야 본문이 보입니다.)">경고문구를 부착합니다.</label>
				</li>
				<li>
					<?php if($tmpFetchBoard['is_bomb']): 
						$getBomb = $GR->getArray("select * from {$dbFIX}time_bomb where id = '$id' and article_num = '$articleNo'");
						$bombTime = date('m월 d일 H시 i분', $getBomb['set_time']);
					?>
					<input type="checkbox" name="is_timebomb" id="is_timebomb" value="1" <?php echo (($getBomb['no'])?'checked="checked"':''); ?> onclick="useBomb();" />
					<label for="is_timebomb" title="체크하면 설정한 폭파시간 이후에 읽혀질 경우 글이 자동으로 삭제 됩니다">일정시간 후 게시물을 삭제합니다. (자동폭파설정)</label>

					<div id="setBomb" style="display: none">
						<?php if($getBomb['no']): ?>
							<p>※ 이 게시물은 <?php echo $bombTime; ?>에 폭파되도록 설정되어 있습니다.</p>
						<?php endif; ?>
			
						<?php if(!$getBomb['no']): ?>
							<input type="text" name="bombTime" value="10" /> 
							<select name="bombTerm">
								<option value="60">분</option>
								<option value="3600">시간</option>
								<option value="86400">일</option>
							</select>
							뒤에 읽혀지면 폭파됩니다.
						<?php endif; ?>
					</div>
					<?php endif; ?>
				</li>
			</ul>
		</li>
		<li><strong class="name">댓글설정</strong>
			<ul class="list2">
				<li>
					<input type="checkbox" id="option_reply_open" name="option_reply_open" value="1" <?php echo (($modify['option_reply_open'] || !$mode)?'checked="checked"':''); ?> /> 
					<label for="option_reply_open" title="체크하면 이 게시물에 댓글을 허용합니다.">이 게시물에 댓글을 허용합니다.</label>
				</li>
				<li>
					<input type="checkbox" name="option_reply_notify" id="option_reply_notify" value="1" <?php echo (($modify['option_reply_notify'])?'checked="checked"':''); ?> />
					<label for="option_reply_notify" title="체크하면 이 게시물에 댓글이 달릴 때 쪽지로 알려줍니다.">댓글이 달리면 쪽지로 알립니다.</label>
				</li>
			</ul>
		</li>
	</ul>
</div>

<?php if(!$isMember): ?>
<fieldset id="write">
	<legend>글쓴이 정보 입력</legend>
<div class="field">
	<div class="inline">
		<label for="name">이름 <span class="notice spIcon">(필수)</span></label>
		<input type="text" name="name" id="name" class="miniInput" value="<?php echo $modify['name']; ?>" />
	</div>
	<div class="inline">
		<label for="password">비밀번호 <span class="notice spIcon">(필수)</span></label>
		<input type="password" id="password" class="miniInput" name="password" />
	</div>
</div>
<div class="field">
	<div class="inline">
		<label for="email">Email</label>
		<input type="text" id="email" name="email" class="miniInput" value="<?php echo $modify['email']?>" /> 
	</div>
	<div class="inline">
		<label for="homepage">Homepage</label>		
		<input type="text" name="homepage" id="homepage" class="miniInput" value="<?php echo $modify['homepage']; ?>" />
	</div>
</div>
<div class="field">
	<div class="inline">
		<label for="antispam"><strong><?php echo $antiSpam0.$antiSpam3.$antiSpam1; ?> = ?</strong> <span class="notice spIcon">(필수)</span></label>		
		<input type="text" name="antispam" id="antispam" class="input" title="<?php echo $antiSpam0.$antiSpam3.$antiSpam1; ?> = ?의 값을 입력해주세요." />
	</div>
</div>
</fieldset>
<?php endif; ?>

<menu class="writeTools">
	<ul>
		<?php if($tmpFetchBoard['is_editor']): ?><li>
			<span class="button large"><input type="button" value="설문조사" onclick="inputPoll('<?php echo $grboard.'/'.$theme; ?>', '<?php echo $id; ?>');" title="설문조사를 작성합니다. 클릭 후 팝업창이 뜨면 그 곳에 안내된 대로 설문을 작성해서 넣어보세요." /></span>
		</li>
		<li>
			<span class="button large"><input type="button" value="글 복구" id="recoveryPostBtn" title="마지막으로 저장된 글을 가져옵니다." /></span>
		</li>
		<li>
			<span class="button large"><input type="button" value="임시저장" onclick="autosave();" title="임시로 글제목과 내용을 저장하고, 계속해서 글을 작성합니다. (자주 눌러주세요!)" /></span>
		</li><?php endif; ?>
		<li>
			<span class="button large icon"><span class="check"></span><input type="submit" accesskey="s" value="작성완료" title="글을 작성 완료 합니다." style="padding-left: 20px;"/></span>
		</li>
		<li>
			<span class="button large icon"><span class="delete"></span><input type="button" value="작성취소" onclick="isCancel('<?php echo $id; ?>');" title="게시물 작성을 취소합니다" style="padding-left: 20px;" /></span>
		</li>
	</ul>
</menu>
</form>

<script>
var USE_EDITOR = false;
</script>

<?php if($tmpFetchBoard['is_editor']): ?>
<script src="<?php echo $grboard; ?>/tiny_mce/tiny_mce.js"></script>
<script>
tinyMCE.init({
	language : "ko",
	mode : "textareas",
	theme : "advanced",
	plugins : "save,style,advimage,advlink,emotions,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste",
	theme_advanced_buttons1 : "newdocument,save,code,|,bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,fontselect,fontsizeselect",
	theme_advanced_buttons2 : "forecolor,backcolor,|,bullist,numlist,|,outdent,indent,blockquote,|,link,unlink,|,image,emotions,media",
	theme_advanced_buttons3 : "",
	theme_advanced_toolbar_location : "top",
	theme_advanced_toolbar_align : "left",
	theme_advanced_statusbar_location : "bottom",	
	content_css : "<?php echo $grboard.'/'.$theme; ?>/edit.css",
	theme_advanced_resizing : true,
	media_use_script : true,
	paste_strip_class_attributes : "all",
	paste_remove_spans : false,
	paste_remove_styles : false,
	forced_root_block : false,
	force_br_newlines : true,
	force_p_newlines : false,
	convert_urls : false,
	
	theme_advanced_fonts : "굴림=굴림;굴림체=굴림체;궁서=궁서;궁서체=궁서체;돋움=돋움;돋움체=돋움체;바탕=바탕;바탕체=바탕체;맑은고딕=Malgun Gothic;나눔고딕=나눔고딕;나눔명조=나눔명조;다음체=다음_Regular;Arial=Arial; Comic Sans MS='Comic Sans MS';Courier New='Courier New';Tahoma=Tahoma;Times New Roman='Times New Roman';Verdana=Verdana"
	
});

var USE_EDITOR = true;
var GRBOARD = '<?php echo $grboard; ?>';
var THEME = '<?php echo $theme; ?>';
var BBS_ID = '<?php echo $id; ?>';
var SESS_ID = '<?php echo session_id(); ?>';
</script>
<?php endif; ?>

<script src="<?php echo $grboard; ?>/js/jquery.js"></script>
<script src="<?php echo $grboard; ?>/js/swfupload.js"></script> 
<script src="<?php echo $grboard; ?>/js/swfupload.queue.js"></script>
<script src="<?php echo $grboard; ?>/js/fileprogress.js"></script>
<script src="<?php echo $grboard; ?>/js/handlers.js"></script>
<script src="<?php echo $grboard.'/'.$theme; ?>/write.js"></script>
</section><!--# 게시판 끝 -->