<?php
if(!$isFirstStart){$isFirstStart = true; ?>
<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<!--[if lt IE 8]><script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE8.js"></script><![endif]-->
<!--[if lt IE 7]><script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE7.js"></script><![endif]-->
<!--[if IE 8]><style type="text/css"> #GRBOARD{position: static}#GRBOARD nav.listTopMenu{top: 4px}#GRBOARD table#grListTable{margin-top: 30px}#GRBOARD .post{margin-top: 30px}#GRBOARD section.write{margin-top: 30px}#GRBOARD #searchIndex{margin-left: 55px; width: 237px;}</style><![endif]-->
<!-- 게시판 시작 -->
<section id="GRBOARD">
<?php } ?>