<?php if(!defined('__GRBOARD__')) exit();  ?>
<div>
<?php if($printPage): ?><nav class="pagelist"><?php echo $printPage; ?></nav><?php endif; ?>

<nav class="listMenu">
	<ul>
	<?php if($isAdmin): /* 관리자만 쓸 수 있는 기능버튼 */ ?><li class="adjust"><span class="button large"><input type="button" onclick="adjustArticle();" title="선택한 글들을 복사/이동/삭제 합니다." value="글관리" style="padding: 0 8px 0 5px; font-size:16px;" /></span></li><?php endif; ?>
	<li><span class="button large"><a href="<?php echo $grboard; ?>/write.php?id=<?php echo $id; ?>&amp;clickCategory=<?php echo $clickCategory; ?>" title="글을 작성합니다.">글쓰기</a></span></li>
	<li><span class="button large"><a href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;page=<?php echo $page; ?>&amp;searchOption=<?php echo $searchOption; ?>&amp;searchText=<?php echo urlencode($searchText); ?>" title="글 목록을 봅니다.">목록</a></span></li>
	<?php if($isRSS): /* RSS 버튼 출력 (가능할 때만) */ ?>
		<li><span class="button large"><a href="<?php echo $grboard; ?>/rss.php?id=<?php echo $id; ?>" id="viewRssBtn" title="RSS 2.0 피드를 열어 봅니다.">RSS</a></span></li>
	<?php endif; ?>
	</ul>
</nav>

<form id="search" method="get" onsubmit="return searchValueCheck();" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<div>
	<input type="hidden" name="searchStart" value="1" />
	<input type="hidden" name="id" value="<?php echo $id; ?>" />
	<input type="hidden" name="division" value="<?php echo $division; ?>" />
	<input type="hidden" name="originDivision" value="<?php echo $originDivision; ?>" />
</div>

<fieldset class="searchBox">
	<legend>검색</legend>
	<select name="searchOption" id="searchOption" title="검색할 종류를 선택하세요.">
		<option value="subject"<?php echo (($searchOption=='subject')?' selected="selected"':''); ?>>글제목</option>
		<option value="name"<?php echo (($searchOption=='name')?' selected="selected"':''); ?>>글작성자</option>
		<option value="content"<?php echo (($searchOption=='content')?' selected="selected"':''); ?>>글내용</option>
		<option value="link1"<?php echo (($searchOption=='link1')?' selected="selected"':''); ?>>링크1</option>
		<option value="link2"<?php echo (($searchOption=='link2')?' selected="selected"':''); ?>>링크2</option>
		<option value="tag"<?php echo (($searchOption=='tag')?' selected="selected"':''); ?>>태그</option>
		<option value="co_name"<?php echo (($searchOption=='co_name')?' selected="selected"':''); ?>>댓글작성자</option>
		<option value="co_content"<?php echo (($searchOption=='co_content')?' selected="selected"':''); ?>>댓글내용</option>
	</select>
    <input type="text" name="searchText" id="searchText" title="검색어를 입력하세요." onkeydown="startSearch('<?php echo $id; ?>');" class="searchInput" value="<?php echo $searchText; ?>" /><input type="submit" class="search" value="검색" title="검색을 시작합니다." />
	<div id="searchIndex" style="display: none;"></div>
</fieldset>
</form>
</div>
<?php if(!$isOutlogin): /* 아웃로그인 사용하지 않을 때에만 출력 */?>
<nav class="listTopMenu">
	<ul>
		<?php if($isAdmin): /* 관리자만 쓸 수 있는 기능버튼 */ ?><li><a href="<?php echo $grboard; ?>/admin_board.php?boardID=<?php echo $id; ?>" onclick="window.open(this.href, '_blank'); return false;" title="관리자 화면으로 가서 이 게시판 설정을 변경 합니다. (새창으로 열립니다.)">관리자</a></li><?php endif;?>
	<?php if($isMember): /* 여기서부터는 로그인 후 출력 */ ?>
		<li><a href="<?php echo $grboard; ?>/info.php?boardId=<?php echo $id; ?>" title="내 정보를 봅니다.">내정보</a></li>
		<li><a href="<?php echo $grboard; ?>/logout.php?id=<?php echo $id; ?>" title="로그아웃 합니다.">로그아웃</a></li>
		<li><a href="<?php echo $grboard; ?>/view_memo.php" id="viewMemoBtn" title="내 쪽지함을 열어 봅니다.">쪽지함</a></li>
		<li><a href="<?php echo $grboard; ?>/view_scrap.php" id="viewScrapBtn" title="내 스크랩북을 열어 봅니다.">스크랩</a></li>
	<?php endif; ?>

	<?php if(!$isMember): /* 여기서부터는 로그인 안한 상태일 때 출력 */ ?>
		<li><a href="<?php echo $grboard; ?>/login.php?boardID=<?php echo $id; ?>" title="로그인 합니다.">로그인</a></li>
		<li><a href="<?php echo $grboard; ?>/join.php?joinInBoard=1&amp;boardId=<?php echo $id; ?>" title="멤버로 등록 합니다.">가입</a></li>
	<?php endif; ?>
	</ul>
</nav>
<?php endif; ?>

<script type="text/javascript">
var GRBOARD = '<?php echo $grboard; ?>/';
</script>
<script type="text/javascript" src="<?php echo $grboard.'/'.$theme; ?>/list.js"></script>
<script type="text/javascript" src="<?php echo $grboard; ?>/js/member_info.js"></script>
<script type="text/javascript" src="<?php echo $grboard; ?>/js/search_helper.js"></script>

</section>