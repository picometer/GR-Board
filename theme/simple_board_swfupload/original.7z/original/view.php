<?php
if(!defined('__GRBOARD__')) exit();
include $theme.'/lib/view_lib.php';
$maxImageWidth = 550; # ← 본문 내 이미지 최대크기 (px)
$content = autoImgResize($maxImageWidth, $content);
?>

<article class="post">
	<header>
		<h1><?php echo $subject; ?></h1>
		<div class="writerInfo">
			<span class="blind">작성자 :</span><span class="viewName bar" onclick="getMember(<?php echo (($view['member_key'])?$view['member_key']:0).','.(($_SESSION['no'])?$_SESSION['no']:0); ?>, event);"><?php echo $view['name']; ?></span>
			<?php $week = array(" 일요일", " 월요일", " 화요일", " 수요일", " 목요일", " 금요일", " 토요일"); $s = $week[date('w', $list['signdate'])]; ?>
			<span class="blind">작성일 :</span><time class="bar" datetime="<?php echo date('c', $view['signdate']); ?>"><?php echo date('Y년m월d일',	$view['signdate']); echo $s; echo date(' H시i분', $view['signdate']); ?> (<?php echo diffDate(date('Y-m-d H:i:s', $view['signdate']),date('Y-m-d H:i:s')); ?>)</time>
			<?php if($isAdmin): ?>
			<span class="blind">IP :</span><span class="viewIP bar"><?php echo $view['ip']; ?></span>
			<?php endif; ?>
			<span class="blind">조회수 :</span><span class="viewHit"><?php echo $view['hit']; ?>명 읽음</span>
		</div>
		

	<?php if($isTrackback||$view['link1']||$view['link2']): ?>
		<ul class="menu">
				<?php $url = "http://" . $_SERVER["HTTP_HOST"] . $_SERVER['PHP_SELF'];  ?>
				<li><span class="button small"><input type="button" onclick="clickToCopy('<?php echo $url; ?>?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>');" title="이 글의 주소를 복사합니다." value="글주소" /></span></li>
				<?php if($isTrackback): ?><li><span class="button small"><input type="button" onclick="clickToCopy('<?php echo $trackbackUrl; ?>');" title="이 글의 엮인글(트랙백) 주소를 복사합니다." value="트랙백" /></span></li><?php endif; ?>
				<?php if($view['link1']): ?><li><span class="button small"><input type="button" onclick="window.open('<?php echo htmlspecialchars($view['link1']); ?>', '_blank'); return false;" title="링크 #1 이 있습니다." value="링크1" /></span></li><?php endif; ?>
				<?php if($view['link2']): ?><li><span class="button small"><input type="button" onclick="window.open('<?php echo htmlspecialchars($view['link2']); ?>', '_blank'); return false;" title="링크 #2 이 있습니다." value="링크2" /></span></li><?php endif; ?>
		</ul>
	<?php endif; ?>
	</header>
	<div id="articleContent">
		<?php if($isFiles): for($f=1; $f<11; $f++): if($files[$f]): ?>
		<div id="attachments<?php echo $f ;?>" class="viewImg" style="width: <?php echo $maxImageWidth+2; ?>px;">
			<a href="<?php echo $grboard; ?>/download.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;num=<?php echo $f; ?>" onclick="return hs.expand(this);" ><?php echo showImg($files[$f]); ?>
		</div>	
		<?php endif; endfor; endif;?>
		<?php echo $content; ?>
	</div>
	<footer>
		<h5 class="blind">태그</h5>
		<p class="tag"><span class="spIcon"></span><?php echo $tag; ?></p>
	<?php if($isFiles): ?>
		<h5 class="blind">첨부파일</h5>
		<ol class="articleList">
			<?php for($f=1; $f<11; $f++): if($files[$f]): ?>
			<li class="add"><span class="spIcon"></span><a href="<?php echo $grboard; ?>/download.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;num=<?php echo $f; ?>" class="cutString"><?php echo showText($files[$f]); ?></a></li>
			<?php endif; endfor; ?>
			<?php showAddedFileList(); ?>
		</ol>
	<?php endif; ?>

		<div class="viewMenu">
			<div class="like">
				<span class="button small icon"><span class="add"></span><a href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;good=1" title="이 글이 좋아요!">좋아요 (<?php if($view['good']) echo $view['good']; else echo'일등으로 "좋아요"를 클릭하세요.'; ?>)</a></span>
			</div>
			<ul>
				<li><span class="button small"><a href="<?php echo $grboard; ?>/view_scrap.php?isAdd=1&amp;id=<?php echo $id; ?>&amp;article_num=<?php echo $articleNo; ?>" onclick="window.open('<?php echo $grboard; ?>/view_scrap.php?isAdd=1&amp;id=<?php echo $id; ?>&amp;article_num=<?php echo $articleNo; ?>', 'addScrap', 'width=600,height=650,menubar=no,scrollbars=yes'); return false;" title="이 글을 내 스크랩북에 담습니다.">담기</a></span></li>
				<li><span class="button small"><a href="<?php echo $grboard; ?>/report.php?id=<?php echo $id; ?>&amp;article_num=<?php echo $articleNo; ?>" onclick="window.open('<?php echo $grboard; ?>/report.php?id=<?php echo $id; ?>&amp;article_num=<?php echo $articleNo; ?>', 'addReport', 'width=600,height=650,menubar=no,scrollbars=yes'); return false;" title="이 글을 관리자와 모더레이터에게 신고합니다.">신고</a></span></li>
			<?php if($isAdmin && ($view['bad'] > -1000)): ?>
				<li><span class="button small"><a class="red" href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;blind=on&amp;blindTarget=<?php echo $articleNo; ?>&amp;tableType=bbs_" onclick="blindArticleOk('<?php echo $id.'\', '.$articleNo; ?>, 'bbs_', <?php echo $articleNo; ?>); return false;" title="이 게시물을 블라인드 처리 합니다. (삭제하지는 않고, 게시물 내용만 확인이 안됩니다.)">블라인드</a></span></li>
			<?php endif; ?>
			<?php if($isAdmin && ($view['bad'] < -1000)): ?>
				<li><span class="button small"><a class="green" href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;blind=off&amp;blindTarget=<?php echo $articleNo; ?>&amp;tableType=bbs_" onclick="blindArticleNo('<?php echo $id.'\', '.$articleNo; ?>, 'bbs_', <?php echo $articleNo; ?>); return false;" title="이 게시물의 블라인드 처리를 해제합니다. (가려졌던 게시물 내용이 다시 보입니다.)">블라인드 해제</a></span></li>
			<?php endif; ?>
			</ul>
		</div>
			<fieldset class="viewWriterComment">
			<legend>자기소개</legend>
			<?php echo showMemberInfo($view['member_key']);
			if(!showMemberInfo($view['member_key'])) { echo $view['name']; echo'님의 자기소개 글이 없습니다.'; }
			?>
		</fieldset>
	</footer>
</article>
<script src="<?php echo $grboard; ?>/tiny_mce/plugins/media/js/embed.js"></script>