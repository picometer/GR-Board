<section id="comment">
<?php if(!$GR->fetch($getComment)) { ?><p class="center silver noComment">이 게시물에 달린 댓글이 없습니다.</p><?php } ?>
<?php while($comment = setViewData($GR->fetch($getComment))): ?>

	<article class="article" id="read<?php echo $comment['no']; ?>" <?php if($comment['thread']): ?>style="margin-left: <?php for($tc=0; $tc<$comment['thread']; $tc++) echo $tc*15; ?>px;" <?php endif; ?>>
		<header>
			<h5><span class="name" onclick="getMember(<?php echo (($comment['member_key'])?$comment['member_key']:0).','.(($_SESSION['no'])?$_SESSION['no']:0); ?>, event);">
				<?php echo $comment['name']; ?>
			</span></h5>
			<div class="writeDate">
				<?php if($comment['homepage']) { ?><span class="blind">Homepage :</span><span class="homepage bar"><?php echo $comment['homepage']; ?></span><?php } ?>
				<?php if($comment['email']) { ?><span class="blind">Email :</span><span class="bar"><?php echo $comment['email']; ?></span><?php } ?>
				<span class="blind">작성시간 :</span><span <?php if($isAdmin or $isMaster): ?>class="bar"<?php endif; ?>><time datetime="<?php echo date('c', $comment['signdate']); ?>" title="<?php echo date('Y년m월d일', $comment['signdate']); echo $s; ?> <?php echo date('H시i분s초', $comment['signdate']); ?>에 등록됨."><?php echo diffDate(date('Y-m-d H:i:s', $comment['signdate']),date('Y-m-d H:i:s')); ?></time></span>
				<?php if($isAdmin or $isMaster): ?><span class="blind">IP주소 :</span><span><?php echo $comment['ip']; ?></span><?php endif; ?>
			</div>
		</header>
		<div class="commentArticle">
			<?php echo $comment['content']; ?>
		</div>
		<footer class="footer">
			<div class="commentMenu">
				<div class="like">
					<span class="button small icon"><span class="add"></span><a href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;voteCommentNo=<?php echo $comment['no']; ?>&amp;good=1#read<?php echo $comment['no']; ?>" title="이 댓글이 좋아요!">좋아요 (<?php if($comment['good']) echo $comment['good']; else echo'일등으로 "좋아요"를 클릭하세요.'; ?>)</a></span>
				</div>
				<ul>
					<li><span class="button small"><a href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;replyTarget=<?php echo $comment['no']; ?>&amp;commentPage=<?php echo $_GET['commentPage']; ?>&amp;page=<?php echo $page; ?>#read<?php echo $comment['no']; ?>" onclick="setPos(event);">답글</a></span></li>
					<li><span class="button small"><a href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;modifyTarget=<?php echo $comment['no']; ?>&amp;commentPage=<?php echo $_GET['commentPage']; ?>&amp;page=<?php echo $page; ?>#read<?php echo $comment['no']; ?>" onclick="setPos(event);">수정</a></span></li>
					<li><span class="button small"><a href="<?php echo $grboard; ?>delete.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;commentNo=<?php echo $comment['no']; ?>&amp;targetTable=comment&amp;readyWork=c_delete&amp;page=<?php echo $page; ?>" onclick="commentDeleteOk(<?php echo "'".$id."', ".$articleNo.", ".$comment['no'].", ".$page; ?>); return false;">삭제</a></span></li>
				<?php if($isAdmin && ($comment['bad'] > -1000)): ?>
					<li><span class="button small"><a class="red" href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;blind=on&amp;blindTarget=<?php echo $articleNo; ?>&amp;tableType=comment_" onclick="blindArticleOk('<?php echo $id.'\', '.$articleNo; ?>, 'comment_', '<?php echo $comment['no']; ?>');" title="이 댓글을 블라인드 처리 합니다. (삭제하지는 않고, 댓글 내용만 확인이 안됩니다.)">블라인드</a></span></li>
				<?php endif; ?>
				<?php if($isAdmin && ($comment['bad'] < -1000)): ?>
					<li><span class="button small"><a class="green" href="<?php echo $grboard; ?>/board.php?id=<?php echo $id; ?>&amp;articleNo=<?php echo $articleNo; ?>&amp;blind=off&amp;blindTarget=<?php echo $articleNo; ?>&amp;tableType=comment_" onclick="blindArticleNo('<?php echo $id.'\', '.$articleNo; ?>, 'comment_', '<?php echo $comment['no']; ?>');" title="이 댓글의 블라인드 처리를 해제합니다. (가려졌던 댓글 내용이 다시 보입니다.)">블라인드 해제</a></span></li>
				<?php endif; ?>
				</ul>
			</div>
		</footer>
	</article>
<?php endwhile; ?>
<?php if($printPage): ?><nav class="comment_paging"><?php echo $printPage; ?></nav><?php endif; ?>
</section>