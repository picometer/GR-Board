<?php if(!defined('__GRBOARD__')) exit(); ?>

<form id="commentWrite" onsubmit="return valueCheck(<?php echo $isMember; ?>);" method="post" action="<?php echo $grboard; ?>/comment_write_ok.php">
<div><input type="hidden" name="articleNo" value="<?php echo $articleNo; ?>" />
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<input type="hidden" name="page" value="<?php echo $page; ?>" />
<input type="hidden" name="modifyTarget" value="<?php echo $modifyTarget; ?>" />
<input type="hidden" name="commentPage" value="<?php echo $commentPage; ?>" />
<input type="hidden" name="replyTarget" value="<?php echo $replyTarget; ?>" />
<input type="hidden" name="useCoEditor" value="<?php echo (($tmpFetchBoard['is_comment_editor'])?1:0); ?>" />
<input type="hidden" name="clickCategory" value="<?php echo $clickCategory; ?>" /></div>

<fieldset id="wrtieComment">
	<legend>댓글 <?php if($comment['content']) echo '수정'; else echo'작성'; ?></legend>
	<div class="field">
		<span class="notice spIcon" title="반드시 입력해야 하는 항목입니다.">(필수)</span> <label for="content">내용</label>
		<textarea name="content" id="content" cols="50" rows="5" class="commentTextarea"><?php echo $comment['content']; ?></textarea>
		<?php $allowTag = $GR->getArray('select is_html from '.$dbFIX.'board_list where id = \''.$id.'\''); ?>
		<p class="info"><span>사용가능한 TAG: </span><?php echo $allowTag[is_html]; ?></p>
	</div>
<?php if($_SESSION['no']): ?>
	<div class="field">
		<label for="is_secret" title="게시물 작성자만 볼 수 있도록 비밀 댓글을 작성합니다.">비밀글</label>
		<input type="checkbox" id="is_secret" name="is_secret" style="width: auto; border: 0;" value="1" <?php echo (($comment['is_secret'])?'checked="checked"':''); ?> />
	</div>
<?php endif; ?>
<?php if(!$isMember): ?>
	<div class="field">
		<div class="inline">
			<label for="name"><span class="notice spIcon" title="반드시 입력해야 하는 항목입니다.">(필수)</span> 이름</label>
			<input type="text" name="name" id="name" class="miniInput" maxlength="20" value="<?php echo $comment['name']; ?>" />
		</div>
		<div class="inline">
			<label for="password"><span class="notice spIcon" title="반드시 입력해야 하는 항목입니다.">(필수)</span> 비밀번호</label>
			<input type="password" name="password" id="password" maxlength="40" class="miniInput" />
		</div>
	</div>
	<div class="field">
		<div class="inline">
			<label for="email">Email</label>
			<input type="email" name="email" id="email" class="miniInput" maxlength="250" value="<?php echo $comment['email']; ?>" />
			<label for="homepage">Homepage</label>
			<input type="text" name="homepage" id="homepage" maxlength="250" class="miniInput" value="<?php echo $comment['homepage']; ?>" />
		</div>
	</div>
	<div class="field ">
		<label for="antispam"><span class="notice spIcon" title="반드시 입력해야 하는 항목입니다.">(필수)</span> <?php echo $antiSpam0.$antiSpam3.$antiSpam1; ?> = ?</label>
		<input type="number" name="antispam" id="antispam" style="width: 40px;" title="<?php echo $antiSpam0.$antiSpam3.$antiSpam1; ?> 의 답을 입력하세요." />
	</div>
<?php endif; ?>
	<div class="submit">
		<button type="submit" title="댓글을 등록 합니다" >등록</button>
	</div>
</fieldset>
</form>

<?php if($tmpFetchBoard['is_comment_editor']): ?>
<script type="text/javascript" src="<?php echo $grboard; ?>/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript">
//<![CDATA[
tinyMCE.init({
	language: "ko",
	mode : "textareas",
	theme : "advanced",
	plugins : "emotions,inlinepopups,media",
	
	theme_advanced_buttons1 : "bold,italic,underline,strikethrough,forecolor,|,emotions,image,media,bullist,numlist,link",
	theme_advanced_buttons2 : "",
	theme_advanced_buttons3 : "",
	theme_advanced_buttons4 : "",
	theme_advanced_toolbar_location : "top",
	theme_advanced_toolbar_align : "left",
	theme_advanced_statusbar_location : "bottom",
	
	content_css : "<?php echo $grboard.'/'.$theme; ?>/edit.css",
	
	media_use_script : true,
	paste_strip_class_attributes : "all",
	paste_remove_spans : false,
	paste_remove_styles : false,
	forced_root_block : false,	
	force_br_newlines : true,
	force_p_newlines : false,
	convert_urls : false
});
//]]>
</script>
<?php endif; ?>